select * from capacitacion
where duracion between 30 and 90 or num_asistentes <10;