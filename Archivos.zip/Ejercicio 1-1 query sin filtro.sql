select id, hora, dia, rut_cliente from capacitacion;
