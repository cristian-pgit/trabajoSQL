select * from capacitacion
where duracion=60 and num_asistentes >30;